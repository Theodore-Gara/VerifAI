// One deletion path for both "delete my account" and the admin GDPR hard
// delete. The database row goes first (FK cascades remove every trace), then
// the Firebase identity.
//
// Order matters: the old self-delete deleted the Firebase identity first, so a
// failed database delete left the PII behind with nobody able to sign in and
// retry. The old admin delete removed only the row, so the person could sign
// straight back in and silently get a fresh empty account.
const pool = require('../db/pool');
const { getFirebaseAuth } = require('../db/firebase');

// Support data policy (documented in the README): support data is DELETED with
// the account, not retained or redacted.
//   - support_messages and support_events carry user_id ON DELETE CASCADE, so
//     the users delete below removes the account's rows.
//   - Tickets sent while signed out have no user_id. Those that used the
//     account's email address are deleted too, explicitly, in the same
//     transaction, so an erasure request does not leave the person's contact
//     details behind.
// One transaction: either everything goes or nothing does.
async function deleteProfileAndSupportData(user) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM support_events WHERE user_id = $1', [user.id]);
    await client.query(
      `DELETE FROM support_messages
        WHERE user_id = $1
           OR (user_id IS NULL AND $2::text IS NOT NULL AND lower(email) = lower($2))`,
      [user.id, user.email || null],
    );
    const deleted = await client.query('DELETE FROM users WHERE id = $1 RETURNING id', [user.id]);
    await client.query('COMMIT');
    return deleted.rows.length > 0;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

async function purgeAccount({ userId = null, firebaseUid = null } = {}) {
  const identified = await pool.query(
    `SELECT id, email, firebase_uid
       FROM users
      WHERE ($1::int IS NOT NULL AND id = $1)
         OR ($2::text IS NOT NULL AND firebase_uid = $2)
      LIMIT 1`,
    [userId, firebaseUid],
  );
  const user = identified.rows[0] || null;
  const uid = user?.firebase_uid || firebaseUid || null;

  let hadProfile = false;
  if (user) {
    hadProfile = await deleteProfileAndSupportData(user);
  }

  let firebaseDeleted = false;
  let firebaseError = null;
  if (uid) {
    try {
      await getFirebaseAuth().deleteUser(uid);
      firebaseDeleted = true;
    } catch (err) {
      // Already gone in Firebase is the desired end state.
      if (err.code === 'auth/user-not-found') {
        firebaseDeleted = true;
      } else {
        firebaseError = err.message;
        // The profile is already gone, so this cannot be retried by the user;
        // leave a clear signal for ops instead of failing the request.
        console.error(`Account purge: Firebase identity for user ${user?.id ?? '?'} survived deletion: ${err.message}`);
      }
    }
  }

  return {
    hadProfile,
    email: user?.email ?? null,
    firebaseUid: uid,
    firebaseDeleted,
    firebaseError,
  };
}

module.exports = { purgeAccount };
