# VerifAI Backend — Deliverable 4

Node.js/Express REST API for the VerifAI workplace-readiness mobile application.

## Stack

- Node.js 22+
- Express
- PostgreSQL
- Firebase Admin Authentication
- Node.js test runner + Supertest
- Railway deployment

## Core Deliverable 4 flow

`GET /api/tasks/next` → user answers → `POST /api/tasks/:id/attempt` → deterministic scoring → task attempt saved → skill score updated → XP/level/streak updated → achievements evaluated.

## Quick start

```bash
npm install
npm run check
npm test
npm start
```

Copy `.env.example` to `.env` and configure the database and Firebase credentials first.

## Database

Fresh database:

```text
db/schema.sql
db/seed.sql
```

Existing prototype database:

```text
db/migrate_d4.sql
```

Back up an existing database before migration.

## Support data and retention

Contact messages and support analytics are personal data, so they have a fixed
policy:

- **Account deletion deletes support data.** `services/accountPurge.js` removes
  the account's `support_messages` and `support_events` in the same transaction
  as the profile. Messages sent while signed out that used the account's email
  address are removed too. (Chosen over redaction: nothing is kept for audit.)
- **Resolved messages** are kept for 24 months after `resolved_at`; unresolved
  messages are never pruned. **Analytics events** are kept for 12 months.
- Prune with `npm run support:prune` (dry run, prints counts) and
  `npm run support:prune -- --apply` (deletes in one transaction). Override the
  windows with `SUPPORT_MESSAGE_RETENTION_MONTHS` / `SUPPORT_EVENT_RETENTION_MONTHS`.
  Run it on a schedule (for example monthly).
- The message body is never logged or echoed back, and the optional team email
  contains the ticket reference and category only. Analytics store slugs, enum
  values and small integers only; the text of an FAQ search is not stored.

## Documentation

- `API.md` — endpoint reference
- `docs/openapi.yaml` — OpenAPI specification
- `USER_MANUAL.md` — beginner setup, GitHub and Railway instructions
- `DEPLOYMENT_CHECKLIST.md` — deployment verification
- `TEST_MATRIX.md` — test coverage plan
- `PROJECT_HANDOFF.md` — inherited work, Deliverable 4 additions and verification status
- `AUDIT_AND_FIXES.md` — implementation audit

## Security

Never commit `.env`, Firebase service-account credentials, passwords or API keys.

## Git workflow

Use the team's feature branch `feature/backend-d4-completion`, test locally, then open a Pull Request to `main` for review.
