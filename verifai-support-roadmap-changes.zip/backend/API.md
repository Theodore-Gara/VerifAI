# VerifAI Backend API

Base URL locally: `http://localhost:3000`

## Authentication

Protected endpoints require:

```text
Authorization: Bearer <Firebase ID token>
```

## Endpoints

### GET /api/health
Public database/application health check.

### GET /api/tracks
Public list of industry tracks.

### POST /api/auth/sync
Protected. Creates or updates the authenticated user from Firebase claims.

### GET /api/users/me
Protected. Returns the current user's profile and selected industry track.

### PUT /api/users/profile
Protected. Updates `display_name` and/or `industry_track_id`.

### GET /api/tasks/next
Protected. Returns the next task for the authenticated user's selected industry track. The reference answer is never returned.

Query parameters:

- `feature` — restrict to a feature: `verification`, `judgement`, `risk_governance`, `prompt_design`. Default `verification`.
- `dimension` — display-name alias, e.g. `Verification`, `AI Judgement`, `Risk & Governance`, `Prompt Design`. Must agree with `feature` when both are given; otherwise `400`.

Every task payload carries `feature` and `dimension` (e.g. `"feature": "judgement", "dimension": "AI Judgement"`).

### POST /api/tasks/:id/attempt
Protected. Submits an answer and atomically updates attempt history, skill score, XP, level, streak, readiness and achievements. A normal attempt earns score-proportional XP. Body may include `"practice": true` for a repeat attempt: a practice **pass** earns **half** the XP (once per task, only if the task has never been passed before), and counts as **half** a task toward the skill; practice fails earn nothing.

The request body depends on the task feature:

```json
{
  "decision_option_id": 11,
  "reason_option_id": 14,
  "rationale": "optional free-text rationale"
}
```

- Verification `choice` tasks: `{ "answer_option_id": 31, "rationale": "..." }`.
- Verification `line_text` tasks (legacy): `{ "answer": "...", "reason": "...", "selected_lines": [8, 9] }`.
- To record a practice run (no XP, does not affect skill score): `{ ..., "practice": true }`.

The response includes the score, whether it passed, XP earned, the correct option ids, and the updated `skill_score`, `progress` and `newly_earned_achievements`, plus `request_id`.

### GET /api/tasks/history
Protected. The authenticated user's scored attempts, newest first (practice attempts are excluded).

Query parameters:

- `?limit=<1..50>` — page size (default 20); `?offset=<n>` — pagination offset (default 0).
- `?feature=<key>` — restrict to one feature (`verification`, `judgement`, `risk_governance`, `prompt_design`); `400` if unknown.
- `?passed=true|false` — restrict to passed or failed attempts; `400` if malformed.

Response: `{ attempts: [{ id, task_id, feature, title, score, passed, xp_earned, submitted_at, feedback, answer, rationale, selected_lines }], total, limit, offset }`.

### GET /api/interview/questions
Protected. Returns the interview question bank for the authenticated user's selected track, each with a boolean `practiced` flag.

### POST /api/interview/questions/:id/practice
Protected. Marks a question as practised. Idempotent: practising the same question again returns 200 with the same count. Recomputes the readiness score. Returns the question's `practised_count` and `total`.

### GET /api/progress/me
Protected. Returns XP, level, streak, completed task count, readiness score and per-dimension scores.

### GET /api/progress/me/activity
Protected. Daily activity history plus current streak info. Optional `?days=<1..90>` (default 30) window; values outside the range are clamped.

Response: `{ days, streak: { current, last_activity_date }, activity: [{ activity_date, attempts, xp_earned, passed }] }`. One row per day with at least one attempt, ordered oldest first (practice attempts included but earn no XP).

### GET /api/leaderboard
Protected. Deterministic top-N board ordered by XP (ties broken by readiness score, then user id).

Query parameters:
- `?track=<industry_track_id>` — limit the board to one industry track (default: global)
- `?limit=<1..50>` — board size (default 20)

Response: `{ track_id, leaderboard: [{ rank, user_id, display_name, level, xp, streak, readiness_score, tier }], me: { ...same fields, rank } }`. `me` is always included, with the requesting user's computed rank even when they sit outside the top N.

### GET /api/achievements/me
Protected. Returns achievements earned by the current user.

### GET /api/achievements
Protected. Full achievements catalog — every achievement with an `earned` flag and, when earned, its `earned_at` timestamp, so locked and unlocked states render from one call.

### GET /api/achievements/milestones
Protected. Code-defined track milestones with live progress. Optional `?track=<id>` overrides the user's selected track (400 if neither is set).

Response: `{ track_id, milestones: [{ code, name, description, target, current, achieved }] }`. Milestones cover task completion (first task, all tasks in the track), XP (250, 1000), streak (7 days) and level (5). `achieved` flips as soon as `current >= target`.

### POST /api/assistant/chat
Protected. Sends up to eight conversation messages to the AI assistant. `task_id` is **optional**: with it the assistant is scoped to a task belonging to the authenticated user's selected track; without it this is a general, track-aware assistant. Requests are limited to 8 per user per minute; each message is limited to 1,200 characters.

Request:

```json
{
  "task_id": 123,
  "messages": [{ "role": "user", "content": "Can you give me a hint?" }]
}
```

Pass `?stream=1` (or `"stream": true`) to receive a Server-Sent Events stream: each `data:` frame is `{"delta":"..."}`, terminated by `data: [DONE]`, or `{"error":"..."}` on failure.

Requires `NVIDIA_API_KEY` in the backend environment. Model routing is per use case: `NVIDIA_MODEL_CHAT` and `NVIDIA_MODEL_ANALYSIS` (default `nvidia/nemotron-3.5-super-vl-120b-a12b`) serve every generative surface — the assistant, coach, learning assistant, verification analysis and capstone marking; `NVIDIA_MODEL_LIGHT` (default `nvidia/nemotron-3-super-120b-a12b`) handles background session compaction and memory extraction; and a retryable failure falls back to `NVIDIA_MODEL_FALLBACK` (default `nvidia/nemotron-3-super-120b-a12b`).

### POST /api/verification/analyze
Protected. Vera assesses submitted material and returns a structured report. **The submitted content is never stored** — only metadata and the report are persisted.

Request (all optional except `kind`, but at least one input is required):

```json
{
  "kind": "document",
  "context": "optional extra context the user typed",
  "document_name": "q3.pdf",
  "web_search": true,
  "sources": [
    { "type": "text", "text": "a pasted claim", "label": "optional" },
    { "type": "document", "name": "q3.pdf", "mime": "application/pdf", "base64": "..." },
    { "type": "url", "url": "https://example.com/article" },
    { "type": "citation", "text": "POPIA section 22" }
  ]
}
```

The backend resolves each input: `document` is parsed (`pdf-parse` for PDF, `mammoth` for DOCX, UTF-8 otherwise; **10 MB max**), `url` is fetched and HTML-stripped, `citation` is looked up with Tavily. A legacy top-level `content` string is accepted as a text source. Vera then verifies the combined material, citing live web sources.

Response: `{ "analysis": { id, kind, document_name, overall_status, items_requiring_review, sources_confirmed, summary, report, created_at }, "sources": [{ title, url }], "inputs": [{ type, label, chars }], "web_searched": bool }`. `overall_status` is one  of `appears_sound`, `human_review_required`, `insufficient_evidence`. Rate-limited.

### GET /api/verification/analyses
Protected. The user's recent analyses (metadata + report), newest first. Optional `?limit=<1..50>` (default 20).

### GET /api/lab/lessons
Protected. The AI Lab lesson catalog available to the user's track (plus global lessons), each with section/activity/question counts and the user's progress.

### GET /api/lab/lessons/:code
Protected. One lesson (book) with its textbook `sections`, graded recall `activities` (each with `type`, `prompt`, `payload`, `xp_reward`, `passed` and `attempted`) and assessment `questions`, plus the user's progress. Sections are nested: a **chapter** is a top-level section (`parent_id` null), a **topic** sits under a chapter, and a **subtopic** under a topic; the app renders all of a topic's subtopics together. Opening a lesson records recency (not completion). The response also includes `sources`, `attributions` (ready-made credit lines) and a `share_alike` flag. **Answer keys are withheld** — activities never return `correct`, and questions never return `correct_index`/`explanation`.

### GET /api/lab/lessons/next
Protected. Content rotation. Prefers a lesson the learner has not opened yet; when none remain and `include_seen` is true (the default), it serves the lesson gone longest without a revisit, so seen content is never locked away. Optional `?include_seen=true|false` (default true). Response: `{ lesson, revisited }`; `lesson` is `null` when all content is seen and `include_seen=false`.

### GET /api/lab/sources
Protected. The content-source catalogue ("where our material comes from"): title, author, publisher, edition, URL, licence, licence URL, industry, the date the licence was checked, and notes.

### GET /api/lab/sources/:id
Protected. One source plus the lessons that draw on it (`use_type` and `changes_made` per link). `400` for a malformed id, `404` if unknown.

### GET /api/lab/library
Protected. The catalogue grouped by industry: `{ groups: [{ industry, sources: [...] }] }`.

### POST /api/lab/lessons/:code/progress
Protected. Body `{ "sections_completed": 3, "activities_completed": 1 }`. `sections_completed` counts **topics read**. Counts are monotonic (never decrease) and completion is recomputed (all topics read, all activities done, assessment passed).

### POST /api/lab/lessons/:code/assessment
Protected. Body `{ "answers": [1, 0, 2] }` (one index per question). Graded **server-side** against the stored answer key. Returns `{ result: { score, passed, correct_count, total }, questions: [{ question_id, answered, correct, correct_index, explanation }] }`. Passing threshold is 60.

### POST /api/lab/activities/:id/attempt
Protected. Body `{ "response": <answer>, "practice": false }`. Grades a recall activity **server-side** and returns `{ result: { correct, passed, xp_earned, practice }, explanation, answer }`. A **first non-practice pass** awards the activity's XP (default 10); repeat attempts are practice and earn nothing. The `response` shape depends on `type`:

- `multiple_choice` — the option index (`0`-based).
- `true_false` — a boolean.
- `fill_blank` — a string (matched case-insensitively against accepted answers).
- `matching` — an object `{ "<left>": "<right>", ... }`.
- `ordering` — an array of the items in the chosen order.

### GET /api/lab/assessments
Protected. Capstone assessments (module-level) available to the user's track plus cross-industry ones. Each paper uses **three scenarios**; its sections mix multiple-choice, short-answer (`fill_blank`/`numeric`), `matching`, `multi_select` and one rubric `extended_response`, and every question carries its own `scenario` text. Each carries `total_marks` (75), `time_limit_seconds` (5400 = 90 min), `pass_score` (60), `max_attempts` (3), `question_count`, `attempts_used`, `attempts_remaining`, `best_score`, `passed` and `view_only`.

### GET /api/lab/assessments/:code
Protected. The full paper read-only (scenario, instructions, questions with `marks`/`marking` and answers withheld). `view_only` is true once the attempts are exhausted, at which point the learner can still revisit the paper but cannot start again.

### POST /api/lab/assessments/:code/start
Protected. Opens a timed attempt. Questions are returned in **section order** (a paper has `section` labels such as `Section A · Application` / `Section B · Scenario` / `Section C · Case study`; question order is preserved so sections stay in sequence). Multiple-choice / multi-select **options** are shuffled and the permutation stored. Answer keys and rubrics are withheld. Returns `{ attempt_id, started_at, expires_at, time_limit_seconds, pass_score, total_marks, scenario, instructions, attempts_remaining, questions }`. Each question carries `section` and `marks`; the case-study `scenario` is provided here so the app can show it alongside each question. `404` if not available, `409` when no attempts remain, `400` if it has no questions.

### POST /api/lab/assessments/:code/submit
Protected. Body `{ attempt_id, answers: { "<question_id>": <response> } }`. Grades the **auto-marked** questions server-side (remapping shuffled options). If the paper contains a **rubric** question (e.g. an extended response), the attempt is held and returns `202` with `{ result: { pending_marking: true, score, auto_marks, total_marks, ... }, results }`. Otherwise it finalises immediately: `{ result: { pending_marking: false, score, passed, timed_out, marks_awarded, total_marks, attempts_remaining }, results, xp_earned, tokens_earned, achievement }`. A **first pass** — even on the third attempt after two failures — awards XP + tokens + a badge and feeds the readiness score. Answers submitted more than 30 s past `expires_at` are marked `timed_out` and fail. Response shapes by type: `multiple_choice` index, `true_false` boolean, `fill_blank` string, `matching` `{left:right}` map, `ordering` array, `numeric` a number (or array for multi-part), `multi_select` an array of selected indices, `extended_response` free text. `matching` is awarded partial credit per correct pair.

### POST /api/lab/assessments/:code/attempts/:id/mark
Reviewer/AI-marker endpoint. Body `{ marks: { "<question_id>": <total> | [<per-criterion>] }, marked_by }`. Finalises a `pending_marking` attempt: rubric marks are capped at the question marks, added to the auto marks, and the score, pass, rewards and readiness are applied (a human should spot-check any AI marking). `409` if the attempt is not awaiting marking.

### POST /api/lab/assessments/:code/attempts/:id/ai-mark
Protected. AI-assisted marking. Vera's marker model scores each rubric question against the rubric and stores a **suggestion** (`ai_suggestion`, plus `suggested_marks` and a `projected_score`) without finalising — the attempt stays `pending_marking` until a human confirms via the mark endpoint. `409` if not awaiting marking, `400` if there are no rubric questions.

### POST /api/lab/assessments/:code/attempts/:id/analysis
Protected (owner only). Returns Vera's post-capstone performance report, generated once and cached on the attempt: `{ "analysis": { headline, strengths[], focus[], report }, "cached": bool }`. `400` if the paper is not yet submitted.

### GET /api/history
Protected. One newest-first timeline across scored task attempts, AI Lab practice activities and capstone attempts. Optional `?limit=<1..100>` (default 30). Response: `{ entries: [{ type: task|activity|capstone, id, title, feature, score, passed, xp_earned, created_at }] }`.

### POST /api/lab/coach
Protected. Body `{ "lesson_code": "ai-literacy-book", "messages": [...] }` → a Socratic tutor reply. `?stream=1` streams SSE as above. Rate-limited.

### GET /api/workshop/posts
Protected. Track-scoped community threads, newest first. Optional `?lesson=<code>`, `?limit=<1..50>`, `?offset=<n>`. Each post carries `author_name`, `reply_count`, `reaction_count`, `reacted` and `is_mine`.

### GET /api/workshop/posts/:id/replies
Protected. Replies to a thread, oldest first.

### POST /api/workshop/posts
Protected. Body `{ "body": "...", "lesson_code": "optional", "parent_id": "optional reply target" }`. `body` ≤ 2,000 characters. The post is scoped to the user's industry track.

### POST /api/workshop/posts/:id/react
Protected. Toggles the caller's upvote; returns `{ reacted, reaction_count }`.

### POST /api/workshop/posts/:id/report
Protected. Body `{ "reason": "spam" | "abuse" | "off_topic" | "other" }`. Idempotent per user. A post is auto-hidden once 3 distinct users report it. You cannot report your own post.

### DELETE /api/workshop/posts/:id
Protected. Deletes the caller's own post (and its replies). `403` for another user's post.

### GET /api/rewards
Protected. The active rewards catalog, each with `can_afford`, plus the wallet `{ xp, level, tokens, next_level_xp }`.

### GET /api/rewards/tokens
Protected. Ledger of token grants and spends, newest first. Optional `?limit=<1..100>` (default 20). Also returns the wallet.

### POST /api/rewards/:code/redeem
Protected. Redeems a reward by spending **tokens** (XP and level are never touched). `409` with `{ tokens, cost_tokens }` when the balance is short; `404` for an unknown reward. The balance row is locked so concurrent redemptions cannot both pass.

### POST /api/users/avatar
Protected. Body `{ "image_base64": "...", "mime": "image/png" }` (`image/png`, `image/jpeg` or `image/webp`; ≤ 2 MB). A `data:` URI prefix is tolerated. Stored inline as `bytea`.

### GET /api/users/avatar
Protected. Returns the caller's avatar image, or `404` when none is set.


## Vera — AI assistant with memory

Vera is the app-wide, friendly professional assistant. She keeps track of the learner's progress (skill scores, task outcomes, lab and capstone results), remembers durable observations, and personalises coaching. Sessions and messages are stored per user.

### POST /api/vera/chat
Protected. Body `{ session_id?, messages, context? }`. Only the **newest** entry of `messages` is used (role `user`, up to 2,000 chars); older entries are ignored because the server rebuilds the conversation from the stored session history. `context` is one of `assistant`, `coach`, `lab`, `verification`, `general`. Creates a session when `session_id` is omitted. Vera is a general conversational assistant: she can chat about anything, answers from general knowledge, and only uses the learner's app data when the question calls for it (progress questions get live figures; wellness is raised only when the learner brings up mood or stress; an explicit cross-question uses both). Her system prompt is built from the learner profile, stored memories, her rolling **notes about the learner**, **app-wide knowledge** (task types, lessons, capstones and the rewards catalogue with the learner's token balance), a **wellness snapshot** (mood check-ins and their notes for the last 30 days, 30-day self-care counts and the number of journal entries — never journal content) and the learner's own recent attempts **including the correct answers**, and she is **not gated** — she will state the correct answer to a task or assessment the learner attempted if asked. She may ask one focused follow-up question when it would improve her answer; the exchange refreshes her durable memories and her rolling profile of the learner. Long sessions are compacted in the background once the context nears ~90% of the model's window (`CHAT_CONTEXT_TOKENS`, default 262144): older turns are folded into a running summary and only the recent turns are sent verbatim. Returns `{ session_id, reply }`. Vera searches the web automatically when a cheap planner decides the answer needs current or externally verifiable facts; pass `"web_search": true` to force a search (useful for "verify this claim"). Searches add `sources` and `web_searched` to the response and inject the results into her prompt. `?stream=1` streams SSE; the first event is `{"session_id": <id>}` followed by `{"delta": "..."}` frames and `[DONE]`. Rate-limited (8/min).

### GET /api/vera/sessions
Protected. The user's recent chat sessions.

### GET /api/vera/sessions/:id
Protected. One session with its messages.

### GET /api/vera/memory
Protected. The learner's stored memories (kind + content).

### POST /api/vera/memory
Protected. Body `{ kind, content }`, `kind` ∈ `preference|struggle|strength|goal|fact`, `content` ≤ 300 chars. Idempotent per (user, kind, content).

### DELETE /api/vera/memory/:id
Protected. Removes one of the user's memories.

### GET /api/vera/tips
Protected. Deterministic, cost-free coaching tips derived from the learner profile (weak areas, recent misses, strengths, unfinished lessons, capstones awaiting marking), plus a `summary` of the profile.

## Industry Practice

Informational real-world case studies (scenario → cause → solution), like Interview Practice. Cases are sourced from real reporting.

### GET /api/industry-practice/cases
Protected. Cases for the user's track plus cross-industry ones, each with a `read` flag.

### GET /api/industry-practice/cases/:id
Protected. The full case (`scenario`, `cause`, `solution`, `source_title`, `source_url`). Reading it marks it as read. `404` if not available for the track.

### POST /api/industry-practice/cases/:id/read
Protected. Marks a case as read (idempotent).

## Wellness

Private, per-user wellbeing tools. Mood check-ins and journal entries are **one per day**: re-saving the same date updates that row. Dates are `YYYY-MM-DD` supplied by the client (its own local date), defaulting to the server's `CURRENT_DATE` when omitted. Journal content is **never** shared with Vera — she only sees the number of live entries and the optional mood notes.

### GET /api/wellness/mood
Protected. The caller's check-ins, newest first. Optional `?limit=<1..90>` (default 30). Response: `{ checkins: [{ date, mood, note, updated_at }] }`, `mood` ∈ `Great|Calm|Okay|Stressed|Tired|Low`, `note` is `null` or ≤ 200 characters.

### PUT /api/wellness/mood
Protected. Body `{ "mood": "Calm", "date": "2026-10-19", "note": "Tough morning" }` (`date` and `note` optional). Upserts the day's check-in and returns `{ checkin: { date, mood, note, updated_at } }`. Omitting `note` leaves an existing note untouched; sending `""` clears it. `400` for an unknown mood, a malformed date or a note over 200 characters.

### GET /api/wellness/journal
Protected. The caller's live journal entries, newest first. Optional `?limit=<1..90>` (default 30). Response: `{ entries: [{ date, content, updated_at }] }`. Entries deleted more than 30 days ago are purged.

### PUT /api/wellness/journal
Protected. Body `{ "content": "...", "date": "2026-10-19" }` (`date` optional). Upserts the day's entry and returns `{ entry: { date, content, updated_at } }`; saving a deleted day revives it. `content` is required and ≤ 1,200 characters.

### DELETE /api/wellness/journal/:date
Protected. Soft-deletes that day's entry (it can be restored for 30 days). Returns `{ deleted: true, date }`; `404` when there is no live entry for the date.

### POST /api/wellness/journal/:date/restore
Protected. Undoes a delete (idempotent). Returns `{ restored: true, entry: { date, content } }`; `404` when the day has no entry at all.

### GET /api/wellness/activities
Protected. Self-care counts in the window. Optional `?days=<1..30>` (default 7). Response: `{ days, total, activities: [{ activity, count, last_at }] }`, `activity` ∈ `breathing|journal|step_outside`. Journal entries are counted from the journal itself (one live entry per day), not from logged activity rows, so editing an entry does not inflate the count and deleting one removes it.

### POST /api/wellness/activities
Protected. Body `{ "activity": "breathing" }`. Logs one completion and returns `201 { activity: { id, activity, completed_at } }`. `400` for an unknown activity. Journal entries are tracked by saving the journal, so logging `journal` here is unnecessary (accepted for older clients but not counted).

## Scoring

Scores are always 0–100 and stored per dimension; the highest of any dimension named `best_dimension` drives the `dimension-80` achievement.

- **AI Judgement** and **Risk & Governance**: the decision option and reason option each carry a weight (decision 50 + reason 50). The selected decision scores its full weight when best, half when the neighbouring option, zero otherwise; the reason scores its full weight when correct, zero otherwise.
- **Verification (choice)**: select the single correct answer — 100 or 0.
- **Verification (line_text, legacy)**: reference answers use `Keywords:` concepts. The scoring service normalizes text and checks exact token/phrase presence. The score is the percentage of required concepts matched; flaw-line matches and reasoning keywords add points.

XP:

- practice runs earn 0 XP
- otherwise scaled by score and difficulty: `round(score/100 * difficulty_max)`, with difficulty maxima easy 50 / medium 70 / hard 100
- a pass is `score >= 50` for judgement and risk & governance, `>= 60` for verification
- AI Lab practice activities award their `xp_reward` (default 10) on the **first non-practice pass**; repeat attempts earn none, and a pass still advances the level/token economy

Level:

- level 1 starts at 0 XP
- cumulative XP to reach a level: `250·k + 30·k·(k−1)` where `k = level − 1` (250, 560, 930, …)

Reward tokens:

- XP is a permanent progression metric and is **never spent**. Reward tokens are a separate, spendable currency earned from milestones.
- Each level gained grants `TOKENS_PER_LEVEL` tokens (default 10); each achievement earned grants `TOKENS_PER_ACHIEVEMENT` tokens (default 5).
- A first capstone pass may also grant a token bonus (ledger reason `capstone`).
- Grants are recorded in an append-only ledger (`reward_token_events`) whose `UNIQUE(user_id, reason, ref)` constraint makes them idempotent, so a retried submission cannot double-credit.
- Redemptions (`POST /api/rewards/:code/redeem`) deduct tokens only; XP, level and readiness are untouched.

Readiness:

- the single 0-100 readiness score. Each `skill_scores` dimension is **coverage** of that feature: a task passed on a normal attempt counts as a full task, a task passed only via a **practice** attempt counts as **half**. Readiness is the weighted mean of those skill scores, interview coverage (each question practised counts `100 / total`) and lab capstone results (a `Learning` component, the average of the learner's best passed capstone scores). Weights are renormalised over whichever components have data.
- Recomputed **live** on every scored task, interview practice and capstone pass, so it climbs as more of each module is covered.
- The **tier is derived from readiness**: Novice 0-49, Developing 50-69, Proficient 70-84, Advanced 85-100. It follows the score, so it can rise or fall. There is no separate task-count tier counter.

Streak:

- first activity day starts at 1
- another submission on the same calendar day does not increase the streak
- activity on the next calendar day increments the streak
- a gap of two or more days resets it to 1

## Support, help and meta (public)

Support content is database-driven (help articles, FAQs, industry guides, tour
manifests, About). Reads are **public** (no token needed, so About and Help work
from the login screen). If a valid bearer token is sent it is used to link a
message or event to the account; an invalid token is ignored, never a 401.
List and detail responses carry `version` and an `ETag` (send `If-None-Match`
for a 304). `version` is the newest `updated_at` in the collection as
`YYYY-MM-DDTHH:MM:SSZ`, so it changes on every edit, including two edits on the
same day. Markdown is plain (headings, lists, bold), no raw HTML.

Errors on these routes carry a `code`:
`{ "error", "code", "request_id" }`.

| Method | Path | Notes |
|---|---|---|
| GET | `/api/meta` | `{ api_version, verification: { max_document_bytes, max_pages, max_total_chars, accepted_formats }, support: { tour_version }, limits: { contact_rate_per_hour } }`. Values come from the same constants the validators and limiter use. |
| GET | `/api/support/help?category=` | `{ articles[], categories[], version }`, published only, each with `body_md`. |
| GET | `/api/support/help/:slug` | `{ article, related[], version }`; `404 help_article_not_found`. |
| GET | `/api/support/faqs?topic=&q=` | `{ faqs[], topics[], version }`. `q` is a case-insensitive match on question and answer (max 100 chars). |
| GET | `/api/support/industry-guides` | `{ guides[], version }` (summaries: slug, track, tagline, hero_image). |
| GET | `/api/support/industry-guides/:slug` | `{ guide, related_faqs[], version }`; `404 industry_guide_not_found`. Slugs: `finance`, `legal`, `it-software`, `business-consulting`. |
| GET | `/api/support/about` | `{ about: { title, mission_md, vision_md, south_africa_md, how_it_helps_md, who_for_md, how_it_works[], contact: { email, form, expected_reply }, app_version }, version }`. `contact.email` is `null` unless `SUPPORT_EMAIL` is set. |
| GET | `/api/support/tour?track=` | Without `track`: the global tour. With a guide slug or track id: global steps then that industry's steps. `{ tour_key, global_tour_key, version, autoplay: false, steps[] }`; each step `{ id, title, body_md, media, scope }`, `media` is `null` until a recording is hosted (`body_md` is always the transcript). `404 track_not_found`. |
| POST | `/api/support/contact` | See below. |
| POST | `/api/support/events` | See below. |

### POST /api/support/contact

Body: `{ name, email, subject, message, category, app_version?, website? }`.
`category` is one of `bug, account, content, verification, feedback, other`.
Limits: name 1-100, email valid and at most 254, subject 3-150, message 10-4000.
`website` is a hidden honeypot field: leave it empty in the app. A bot that fills
it gets the normal success response and nothing is stored.

Success is `201 { ticket_id, expected_reply: "1–2 working days", request_id }`.
`ticket_id` is a non-sequential reference such as `VF-7K3Q9M2X`. The message is
never echoed back and never logged. Errors: `400` with `invalid_name`,
`invalid_email`, `invalid_subject`, `invalid_message`, `invalid_category`,
`invalid_app_version` or `invalid_json`; `429 rate_limited` after 5 messages per
hour per account (per IP when signed out). An optional team notification email
(`SUPPORT_NOTIFY_EMAIL`, `RESEND_API_KEY`, `SUPPORT_NOTIFY_FROM`) carries only the
reference and category; if it fails or is not configured the request still
succeeds.

### POST /api/support/events

One event per call: `{ event, target?, metadata? }` where `event` is one of
`help_open, article_view, faq_expand, faq_search, tour_start, tour_complete,
tour_skip, contact_open, contact_submit`. Always `202 { recorded }`: a failed
insert or a rate-limited client returns `recorded: false`, never an error.
`target` is a slug (required for `article_view`, `faq_expand` and `tour_*`).
Only allowlisted metadata keys are stored, and only slugs, enum values or small
integers: `source`, `topic`, `track`, `category`, `result_count`, `steps_viewed`,
`step_index`. Unknown keys and free text are dropped. `faq_search` stores the
result count only, never the search text. Bad `event` is `400 invalid_event`; a
bad `target` is `400 invalid_target`.

## Roadmap

`GET /api/roadmap[?track=<id>]` (auth). The learner's milestone tracker for the
active industry, or another track when previewing. Five ordered stages per
track, two milestones each. Status is derived from existing work on every read:
no per-user roadmap rows, no XP, streak or achievement input.

```json
{
  "track": { "id": 1, "name": "Finance" },
  "summary": { "current_stage": 1, "stages_completed": 0, "milestones_completed": 0,
               "milestones_total": 10, "percent": 0, "readiness_score": 0, "tier": "Novice" },
  "stages": [{ "code": "orient", "title": "Orientation", "outcome": "...", "order": 1,
               "status": "active",
               "milestones": [{ "code": "tour", "title": "Take the Finance tour", "description": "...",
                                "status": "current", "current": 0, "target": 1, "unit": "tour",
                                "action": { "label": "Take the tour", "route": "/welcome-tour" } }] }],
  "next_action": { "stage": "orient", "milestone": "tour", "label": "Take the tour", "route": "/welcome-tour" },
  "credential": { "title": "AI Readiness Passport", "description": "...", "unlocked": false },
  "request_id": "..."
}
```

- `stage.status`: `complete`, `active` or `locked`. A stage is complete when all
  its milestones are complete and every earlier stage is complete; the first
  incomplete stage is active; every later stage is locked.
- `milestone.status`: `complete`, `current` (the next action), `up_next` or
  `locked`. A milestone already satisfied by evidence is `complete` even inside a
  locked stage, and counts in `milestones_completed`.
- `current` counts distinct passed rows (capped at `target`) for counters, and the
  best-ever value for scores (`capstone_score`, `readiness_score`), so a later drop
  in live readiness never un-reaches a milestone. `summary.readiness_score` is the
  live value.
- Counters use passed, non-practice task attempts, distinct tasks, cases and
  activities. Evidence is never taken from the client.
- `next_action` is null only when every stage is complete.
- Errors: `400 invalid_track`, `400 track_required` (no industry chosen),
  `404 track_not_found`.

## Admin support console

Moderators read, admins write. Every content edit and ticket status change is
written to the audit trail (`/api/admin/moderation`).

| Method | Path | Role | Notes |
|---|---|---|---|
| GET | `/api/admin/support/help?category=&published=` | moderator | All articles, including unpublished. |
| PUT | `/api/admin/support/help/:id` | admin | Any of `title, summary, body_md, category, sort_order, published`. Slugs are immutable. Returns `{ article, changed[] }`; a no-op edit changes nothing. |
| GET | `/api/admin/support/faqs?topic=&published=` | moderator | |
| PUT | `/api/admin/support/faqs/:id` | admin | Any of `question, answer_md, topic, sort_order, published`. |
| GET | `/api/admin/support/messages?status=&category=&limit=&offset=` | moderator | Contains personal data. |
| PUT | `/api/admin/support/messages/:id` | admin | `status` (`new`, `in_progress`, `resolved`) and/or `internal_note`. |
| GET | `/api/admin/support/insights?days=30` | moderator | Top articles, top FAQ topics and FAQs, searches with no result (rate, not text), tour skip rate, contact volume by category. |

Content edits show on the public API at once on that instance; other instances
catch up when their cache entry expires (`CONTENT_CACHE_MS`, default 60 s).

## Error format

Errors use:

```json
{
  "error": "Human-readable message",
  "request_id": "correlation-id"
}
```

Support, roadmap and meta routes also include a machine-readable `code`
(`{ "error", "code", "request_id" }`). A malformed JSON body is
`400 { "code": "invalid_json" }` on every route.

## Database setup

For a new database run:

1. `npm run db:setup` — applies `db/schema.sql`, then `db/seed.sql` and every `db/seed/*.sql` content file (AI Lab lessons, rewards catalog), then baselines migrations.

For an existing database:

- `npm run db:migrate` — applies any pending `db/migrations/NNN_*.sql` (e.g. `007_product_hub.sql`).
- `npm run db:seed` — re-applies seed data only.

For the original prototype database, back it up and review `db/migrations/001_prototype_to_d4.sql` before running it once.

See `USER_MANUAL.md` for beginner setup and GitHub/Railway instructions.
